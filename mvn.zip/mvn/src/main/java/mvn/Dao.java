package mvn;

public class Dao {
public void conn() {
	System.out.println("db접속");
}
}
