package login.dao;

import login.vo.LoginVO;

public interface LoginDaoInter {

	boolean login(LoginVO vo);

}
