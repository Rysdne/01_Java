package index.dao;

public interface IndexDaoInter {

	void tableCheck();
	void close();

}
