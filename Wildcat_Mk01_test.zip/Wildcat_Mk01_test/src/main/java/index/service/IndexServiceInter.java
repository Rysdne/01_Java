package index.service;

public interface IndexServiceInter {

	void init();

}
