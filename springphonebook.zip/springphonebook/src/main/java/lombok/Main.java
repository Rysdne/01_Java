package lombok;

public class Main {

	public static void main(String[] args) {

		Student s = new Student();
		s.setName("hong");
		s.setHp("010-1111-2222");
		System.out.println(s.getName());
		System.out.println(s.getHp());
		
		Student s1 = new Student("hong1","010-3333-4444");
		System.out.println(s1.toString());
		
	}
}
